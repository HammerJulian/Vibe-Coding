sap.ui.define([
    "sap/dm/dme/pod2/widget/Widget",
    "sap/dm/dme/pod2/widget/metadata/WidgetProperty",
    "sap/dm/dme/pod2/propertyeditor/BooleanPropertyEditor",
    "sap/dm/dme/pod2/propertyeditor/StringPropertyEditor",
    "sap/dm/dme/pod2/propertyeditor/PropertyCategory",
    "sap/dm/dme/pod2/context/PodContext",
    "sap/m/Button",
    "sap/m/ComboBox",
    "sap/m/FlexBox",
    "sap/m/Input",
    "sap/m/Label",
    "sap/m/Panel",
    "sap/m/Title",
    "sap/m/Toolbar",
    "sap/m/ToolbarSpacer",
    "sap/ui/core/Item",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], (
    Widget,
    WidgetProperty,
    BooleanPropertyEditor,
    StringPropertyEditor,
    PropertyCategory,
    PodContext,
    Button,
    ComboBox,
    FlexBox,
    Input,
    Label,
    Panel,
    Title,
    Toolbar,
    ToolbarSpacer,
    Item,
    Filter,
    FilterOperator
) => {
    "use strict";

    const FILTER_FIELDS = [
        { key: "sfc",        label: "SFC",         propKey: "sfcVisible",        type: "combo",  contextPath: "/workList/list", contextField: "sfc" },
        { key: "order",      label: "Order",        propKey: "orderVisible",       type: "combo",  contextPath: "/workList/list", contextField: "order" },
        { key: "operation",  label: "Operation",    propKey: "operationVisible",   type: "input",  contextPath: null },
        { key: "material",   label: "Material",     propKey: "materialVisible",    type: "combo",  contextPath: "/workList/list", contextField: "materialDescription" },
        { key: "resource",   label: "Resource",     propKey: "resourceVisible",    type: "input",  contextPath: null },
        { key: "status",     label: "Status",       propKey: "statusVisible",      type: "combo",  contextPath: "/workList/list", contextField: "sfcStatusDescription" },
        { key: "workcenter", label: "Work Center",  propKey: "workcenterVisible",  type: "input",  contextPath: null }
    ];

    class WorklistExtendedWidget extends Widget {

        #oInputs = {};
        #oContainer = null;

        static getDisplayName() {
            return "Worklist Filter Extended";
        }

        static getDescription() {
            return "Filter bar with dropdowns for SFC, Order, Material, Status and free text for Operation, Resource, Work Center.";
        }

        static getIcon() {
            return "sap-icon://filter";
        }

        static getCategory() {
            return "Custom Widgets";
        }

        static getDefaultConfig() {
            return {
                properties: {
                    sfcVisible:        true,
                    orderVisible:      true,
                    operationVisible:  true,
                    materialVisible:   true,
                    resourceVisible:   false,
                    statusVisible:     true,
                    workcenterVisible: false,
                    // Default filter values
                    sfcDefault:        "",
                    orderDefault:      "",
                    operationDefault:  "",
                    materialDefault:   "",
                    resourceDefault:   "",
                    statusDefault:     "",
                    workcenterDefault: ""
                }
            };
        }

        getProperties() {
            const aVisProps = FILTER_FIELDS.map(f =>
                new WidgetProperty({
                    displayName: f.label + " filter visible",
                    description: "Show or hide the " + f.label + " filter field.",
                    category: PropertyCategory.Main,
                    propertyEditor: new BooleanPropertyEditor(this, f.propKey)
                })
            );

            const aDefaultProps = FILTER_FIELDS.map(f =>
                new WidgetProperty({
                    displayName: f.label + " default value",
                    description: "Default/fixed filter value for " + f.label + ". Leave empty for no default.",
                    category: PropertyCategory.Main,
                    propertyEditor: new StringPropertyEditor(this, f.key + "Default")
                })
            );

            return [...aVisProps, ...aDefaultProps];
        }

        getPropertyValue(sName) {
            const vValue = super.getPropertyValue(sName);
            if (FILTER_FIELDS.some(f => f.propKey === sName)) {
                return vValue !== false;
            }
            return vValue;
        }

        setPropertyValue(sName, vValue) {
            super.setPropertyValue(sName, vValue);
            const oField = FILTER_FIELDS.find(f => f.propKey === sName);
            if (oField && this.#oInputs[oField.key]) {
                this.#oInputs[oField.key].getParent().setVisible(!!vValue);
            }
        }

        _createView() {
            const aFilterItems = FILTER_FIELDS.map(f => {
                let oInput;
                const sDefault = this.getPropertyValue(f.key + "Default") || "";

                if (f.type === "combo" || f.type === "status") {
                    oInput = new ComboBox({
                        width: "180px",
                        placeholder: "Select or type " + f.label + "...",
                        value: sDefault,
                        items: [],
                        selectionChange: this.#onSearch.bind(this),
                        change: this.#onSearch.bind(this)
                    });

                    // Load dynamic values from POD Context for combo fields
                    if (f.type === "combo" && f.contextPath) {
                        this.#loadComboItems(oInput, f.contextPath, f.contextField);

                        // Subscribe to worklist changes to update dropdown
                        PodContext.subscribe(f.contextPath, () => {
                            this.#loadComboItems(oInput, f.contextPath, f.contextField);
                        }, this);
                    }
                } else {
                    oInput = new Input({
                        width: "180px",
                        placeholder: "Enter " + f.label + "...",
                        value: sDefault,
                        liveChange: this.#onSearch.bind(this),
                        submit: this.#onSearch.bind(this)
                    });
                }

                this.#oInputs[f.key] = oInput;

                return new FlexBox({
                    direction: "Column",
                    visible: this.getPropertyValue(f.propKey),
                    items: [
                        new Label({ text: f.label }),
                        oInput
                    ]
                }).addStyleClass("sapUiSmallMarginEnd sapUiSmallMarginBottom");
            });

            const oFilterRow = new FlexBox({
                wrap: "Wrap",
                alignItems: "End",
                items: aFilterItems
            }).addStyleClass("sapUiSmallMargin");

            const oToolbar = new Toolbar({
                content: [
                    new Title({ text: "Worklist Filter" }),
                    new ToolbarSpacer(),
                    new Button({
                        text: "Reset",
                        icon: "sap-icon://clear-filter",
                        press: this.#onReset.bind(this)
                    }),
                    new Button({
                        text: "Search",
                        type: "Emphasized",
                        icon: "sap-icon://search",
                        press: this.#onSearch.bind(this)
                    })
                ]
            });

            this.#oContainer = new Panel(this.getId(), {
                headerToolbar: oToolbar,
                content: [oFilterRow]
            });

            // Automatisch filtern wenn mindestens ein Default-Wert konfiguriert ist
            const bHasDefaults = FILTER_FIELDS.some(f =>
                !!(this.getPropertyValue(f.key + "Default") || "").trim()
            );
            if (bHasDefaults) {
                setTimeout(() => this.#onSearch(), 0);
            }

            return this.#oContainer;
        }

        // ── Load combo items from POD Context ────────────────────────────

        #loadComboItems(oCombo, sContextPath, sField) {
            try {
                const aList = PodContext.get(sContextPath);
                if (!Array.isArray(aList) || !aList.length) return;

                // Extract unique values
                const aValues = [...new Set(
                    aList.map(o => o[sField]).filter(Boolean)
                )].sort();

                // Rebuild items
                const sCurrentVal = oCombo.getValue();
                oCombo.removeAllItems();
                aValues.forEach(sVal => {
                    oCombo.addItem(new Item({ key: sVal, text: sVal }));
                });

                // Restore current value
                if (sCurrentVal) oCombo.setValue(sCurrentVal);

                console.info("[WorklistExtendedWidget] Loaded", aValues.length, "items for", sField);
            } catch (e) {
                console.warn("[WorklistExtendedWidget] Error loading combo items:", e.message);
            }
        }

        // ── Search ────────────────────────────────────────────────────────

        #onSearch() {
            const aActiveFilters = [];

            FILTER_FIELDS.forEach(f => {
                const oInput = this.#oInputs[f.key];
                const sVal = oInput
                    ? (oInput.getValue ? oInput.getValue() : "").trim()
                    : "";
                if (!sVal) return;

                // Map filter key to actual table field name from POD config
                const sPath = {
                    sfc:        "sfc",
                    order:      "order",
                    operation:  "operationActivity",
                    material:   "materialDescription",
                    resource:   "resource",
                    status:     "sfcStatusDescription",
                    workcenter: "workCenter"
                }[f.key];

                if (sPath) {
                    aActiveFilters.push(
                        new Filter({ path: sPath, operator: FilterOperator.Contains, value1: sVal })
                    );
                }
            });

            const oFinalFilter = aActiveFilters.length > 0
                ? new Filter({ filters: aActiveFilters, and: true })
                : null;

            this.#applyFilterToWorklist(oFinalFilter);
        }

        // ── Reset ─────────────────────────────────────────────────────────

        #onReset() {
            FILTER_FIELDS.forEach(f => {
                const oInput = this.#oInputs[f.key];
                if (!oInput) return;
                const sDefault = this.getPropertyValue(f.key + "Default") || "";
                oInput.setValue ? oInput.setValue(sDefault) : null;
            });
            this.#applyFilterToWorklist(null);
        }

        // ── Apply filter ──────────────────────────────────────────────────

        #applyFilterToWorklist(oFilter) {
            let bApplied = false;
            try {
                document.querySelectorAll('[id]').forEach(el => {
                    const oControl = sap.ui.getCore().byId(el.id);
                    if (!oControl) return;
                    const bIsTable = oControl.isA && (
                        oControl.isA("sap.m.Table") || oControl.isA("sap.ui.table.Table")
                    );
                    if (!bIsTable) return;
                    const oBinding = oControl.getBinding("items") || oControl.getBinding("rows");
                    if (!oBinding) return;
                    oBinding.filter(oFilter ? [oFilter] : []);
                    bApplied = true;
                });
            } catch (e) {
                console.error("[WorklistExtendedWidget] Filter error:", e);
            }
            if (!bApplied) console.warn("[WorklistExtendedWidget] No table found.");
        }

        onExit() {
            // PodContext Subscriptions aufräumen
            FILTER_FIELDS.forEach(f => {
                if (f.contextPath) {
                    try { PodContext.unsubscribe(f.contextPath, this); } catch (e) { /* ignorieren */ }
                }
            });
            Object.values(this.#oInputs).forEach(o => o.destroy && o.destroy());
            this.#oInputs = {};
            super.onExit && super.onExit();
        }
    }

    return WorklistExtendedWidget;
});
